var soCount = 0;
var temp = "";

function clearCounter(){
	var back = chrome.extension.getBackgroundPage();
	soCount = back.clearCounter();
	displayCount(soCount);
}

function displayCount(count){
	console.log(count);
	document.getElementById('count').innerHTML = "You visited SO " + count;
}

var someCount = chrome.extension.getBackgroundPage();
soCount=someCount.getSOCount();
displayCount(soCount);
