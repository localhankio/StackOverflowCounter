var soCount = 0;
var amazingCleanUpSound = new Audio("./audio/oxp.wav");
//playSound(amazingCleanUpSound);
chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
 
    console.log(request.visitCount);
    soCount = request.visitCount;
    sendResponse({thankyou: "thanks "});
    
});


function clearCounter(){
	chrome.runtime.sendMessage({"clear": true}, function(response){
		console.log(response);
		if (response.byeee){
			return 0;
		}
		else{
			return 1; //this shouldnt happen 
		}
	})
}
function playSound(audio){
	audio.play();
	console.log("PLAYING SOUND")
}

function getSOCount(){
	console.log(soCount);
	return soCount;
}

chrome.tabs.onCreated.addListener(function(tab){
	console.log("tab created");
	var maxTabs = 10;
	chrome.tabs.query({}, function(tabs){
		if (tabs.length > maxTabs) { // should be bigger ,but oh well 
			var delRand = Math.floor(Math.random()*maxTabs);
			chrome.tabs.remove(tabs[delRand].id, function(){
				playSound(amazingCleanUpSound);
				alert("Cleaned up a tab! You're Welcome!")
			})
		}
		
		if(tabs.length == 5)
		{alert("Congrats! You have 5 tabs open!");
		amazingCleanUpSound.play();
		}
	
		if(tabs.length == 7)
		{
			alert("AYYYY 20 TABS");
			amazingCleanUpSound.play();
		}
	
		if(tabs.length == 10)
		{
			alert("Uh oh... 50");
			amazingCleanUpSound.play();
		}
	
		if(tabs.length == 12)
		{alert("You seem to be really good with your fingers...");}
	});
});
