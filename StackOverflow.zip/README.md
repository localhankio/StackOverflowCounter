# StackOverflowCounter
A Chrome extension to count how many times you visit Stack Overflow to get help for your projects 
